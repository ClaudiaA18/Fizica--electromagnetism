1) adaptat, l3 = 0.5 m
2) neadaptat (gol la capatul din dreapta)
3) neadaptat (gol la capatul din dreapta) si l2 = 366 m
4) adaptat, l2 = 66 m, dar l3 = 10 m