
2D and 3D model of an inductor/core system.

Model developed by Ruth V. Sabariego.

Quick start
-----------

Open `inductor.pro' with Gmsh.

